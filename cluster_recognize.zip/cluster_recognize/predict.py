import sys
import pickle
import pandas as pd

with open("model.pkl", "rb") as f:
    model = pickle.load(f)

path = sys.argv[1] if len(sys.argv) > 1 else "dataset.csv"
data = pd.read_csv(path)

cols = [c for c in data.columns if c.startswith("feature_")]
if not cols:
    cols = [c for c in data.columns if c != "cluster"]

preds = model.predict(data[cols].values)

data["predicted_cluster"] = preds
data.to_csv("test_predictions.csv", index=False)
print(f"Предсказания сохранены в test_predictions.csv ({len(preds)} строк)")

if "cluster" in data.columns:
    from sklearn.metrics import adjusted_rand_score
    print("ARI:", adjusted_rand_score(data["cluster"], preds))
