import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import joblib

def load_data(filepath="dataset.csv"):
    data = pd.read_csv(filepath)
    print(f"Данные загружены: {data.shape[0]} строк, {data.shape[1]} колонок")
    return data

def find_clusters_count(X):
    print("Подбираем оптимальное число кластеров...")
    k_range = list(range(2, 11))
    wcss = []  # within-cluster sum of squares

    for k in k_range:
        km = KMeans(n_clusters=k, init='k-means++', n_init=10, random_state=42)
        km.fit(X)
        wcss.append(km.inertia_)
        print(f"k = {k:2d} | WCSS = {km.inertia_:.1f}")

    # График локтя
    plt.figure(figsize=(8, 5))
    plt.plot(k_range, wcss, 's-', color='darkgreen', linewidth=2, markersize=6)
    plt.axvline(x=5, color='orange', linestyle=':', linewidth=2, label='Точка перегиба (k = 5)')
    plt.title("Определение числа кластеров (WCSS)")
    plt.xlabel("Параметр k")
    plt.ylabel("Сумма квадратов расстояний (WCSS)")
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend()
    plt.tight_layout()
    plt.savefig("elbow_curve.png", dpi=150)
    plt.close()
    print("График локтя сохранен в elbow_curve.png")

def train_and_visualize(data, k=5):
    X = data.values
    
    print(f"Обучение KMeans для k={k}...")
    model = KMeans(n_clusters=k, init='k-means++', n_init=15, random_state=42)
    labels = model.fit_predict(X)

    # Сохраняем модель через joblib
    joblib.dump(model, "kmeans_model.joblib")
    print("Модель сохранена в kmeans_model.joblib")

    # Сохраняем датасет с кластерами
    res_df = data.copy()
    res_df['cluster_label'] = labels
    res_df.to_csv("result_clusters.csv", index=False)
    print("Разбиение сохранено в result_clusters.csv")

    # Снижение размерности PCA для графика
    pca = PCA(n_components=2, random_state=42)
    X_reduced = pca.fit_transform(X)
    centers_reduced = pca.transform(model.cluster_centers_)

    # Рисуем 2 графика в одном окне: карту кластеров и распределение по размерам
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    # Левый график: PCA 2D
    scatter = ax1.scatter(X_reduced[:, 0], X_reduced[:, 1], c=labels, cmap='Set2', s=3, alpha=0.5)
    ax1.scatter(centers_reduced[:, 0], centers_reduced[:, 1], c='black', marker='*', s=250, label='Центроиды')
    ax1.set_title(f"Кластеры в проекции PCA (k={k})")
    ax1.set_xlabel("Компонента 1")
    ax1.set_ylabel("Компонента 2")
    ax1.grid(True, linestyle='--', alpha=0.5)
    ax1.legend()
    plt.colorbar(scatter, ax=ax1, label='Кластер')

    # Правый график: количество точек в каждом кластере
    counts = pd.Series(labels).value_counts().sort_index()
    bars = ax2.bar(counts.index.astype(str), counts.values, color='teal', edgecolor='black', alpha=0.7)
    ax2.set_title("Размеры кластеров (баланс выборки)")
    ax2.set_xlabel("Номер кластера")
    ax2.set_ylabel("Количество точек")
    ax2.grid(axis='y', linestyle='--', alpha=0.7)

    for bar in bars:
        h = bar.get_height()
        ax2.annotate(f"{h}", (bar.get_x() + bar.get_width()/2, h),
                     ha='center', va='bottom', xytext=(0, 3), textcoords='offset points')

    plt.tight_layout()
    plt.savefig("clusters_visualization.png", dpi=150)
    plt.close()
    print("Итоговые графики сохранены в clusters_visualization.png")

def main():
    df = load_data("dataset.csv")
    X = df.values
    find_clusters_count(X)
    train_and_visualize(df, k=5)
    print("\nРабота завершена успешно!")

if __name__ == "__main__":
    main()
