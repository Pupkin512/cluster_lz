import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import pickle

df = pd.read_csv("dataset.csv")
print("Размер датасета:", df.shape)
X = df.values

# Метод локтя для поиска k
inertias = []
k_range = range(2, 11)

for k in k_range:
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans.fit(X)
    inertias.append(kmeans.inertia_)
    print(f"k = {k}: инерция = {kmeans.inertia_:.0f}")

plt.figure(figsize=(8, 5))
plt.plot(k_range, inertias, 'bo-')
plt.axvline(5, color='r', linestyle='--', label='Локоть при k=5')
plt.title("Метод локтя")
plt.xlabel("Число кластеров k")
plt.ylabel("Inertia")
plt.grid(True)
plt.legend()
plt.savefig("elbow.png")
plt.close()

# Кластеризуем на 5 групп
model = KMeans(n_clusters=5, random_state=42, n_init=10)
labels = model.fit_predict(X)

df['cluster'] = labels
df.to_csv("clustered_dataset.csv", index=False)

with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

# Визуализация в 2D через PCA
pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X)
centers_pca = pca.transform(model.cluster_centers_)

plt.figure(figsize=(9, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels, cmap='tab10', s=2, alpha=0.4)
plt.scatter(centers_pca[:, 0], centers_pca[:, 1], c='red', marker='x', s=150, linewidths=2, label='Центры')
for i, (x, y) in enumerate(centers_pca):
    plt.annotate(f"Кл. {i}", (x, y), xytext=(5, 5), textcoords='offset points', weight='bold')

plt.title("Кластеризация K-Means (k=5) в PCA")
plt.xlabel("Главная компонента 1")
plt.ylabel("Главная компонента 2")
plt.legend()
plt.grid(True)
plt.savefig("clusters.png")
plt.close()

print("\nГотово. Распределение точек по кластерам:")
print(df['cluster'].value_counts().sort_index())
