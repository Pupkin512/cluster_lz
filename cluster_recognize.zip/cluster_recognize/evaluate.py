import sys
import joblib
import pandas as pd
from sklearn.metrics import adjusted_rand_score

def run_evaluation():
    # Загрузка обученной модели
    model = joblib.load("kmeans_model.joblib")
    
    # Файл для проверки
    input_file = sys.argv[1] if len(sys.argv) > 1 else "dataset.csv"
    print(f"Тестирование модели на файле: {input_file}")
    
    df = pd.read_csv(input_file)
    
    # Отделяем числовые признаки для предсказания
    features = [c for c in df.columns if c.startswith("feature_")]
    if not features:
        features = [c for c in df.columns if c not in ("cluster", "cluster_label")]
        
    X_test = df[features].values
    preds = model.predict(X_test)
    
    # Сохранение результатов
    out_df = df.copy()
    out_df["cluster_predicted"] = preds
    output_filename = "predicted_labels.csv"
    out_df.to_csv(output_filename, index=False)
    print(f"Предсказанные кластеры записаны в {output_filename}")
    
    # Оценка качества при наличии эталонных меток
    target_col = None
    for candidate in ("cluster", "cluster_label", "target", "label"):
        if candidate in df.columns:
            target_col = candidate
            break
            
    if target_col:
        ari = adjusted_rand_score(df[target_col], preds)
        print(f"Метрика качества Adjusted Rand Index (ARI): {ari:.4f}")

if __name__ == "__main__":
    run_evaluation()
